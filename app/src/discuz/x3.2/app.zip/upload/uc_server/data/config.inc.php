<?php 
define('UC_DBHOST', 'mysql:3306');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'openrasp');
define('UC_DBNAME', 'ultrax');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', 'pre_ucenter_');
define('UC_COOKIEPATH', '/');
define('UC_COOKIEDOMAIN', '');
define('UC_DBCONNECT', 0);
define('UC_CHARSET', 'utf-8');
define('UC_FOUNDERPW', '3cad61b538042c181683c0505b404c81');
define('UC_FOUNDERSALT', 'BctfFe');
define('UC_KEY', 'NcMfteP6Z3Taf9K5zeh1B6B2q905x6DctemfpdO2B7f57dr6dfaf152alckcKesf');
define('UC_SITEID', 'tcEfueN6E3oad985Jex1H6q2S9m5l6Rcje0fQdv2d705Udq66fLf25XaDcTczeff');
define('UC_MYKEY', 'lcEfmem6h3Ga69W58eD1i6s2Y975W6ycXenfUdW2R7m5ZdU64fnfY5JaKcvcDejf');
define('UC_DEBUG', false);
define('UC_PPP', 20);
